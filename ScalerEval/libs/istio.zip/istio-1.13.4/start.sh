export PATH=$PWD/bin:$PATH
istioctl install --set profile=demo -y
