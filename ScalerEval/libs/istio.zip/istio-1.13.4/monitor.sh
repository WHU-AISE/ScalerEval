kubectl apply -f samples/addons
