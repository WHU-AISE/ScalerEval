kubectl delete -f samples/addons
export PATH=$PWD/bin:$PATH
istioctl manifest generate --set profile=demo | kubectl delete --ignore-not-found=true -f -
istioctl tag remove default
kubectl delete namespace istio-system
